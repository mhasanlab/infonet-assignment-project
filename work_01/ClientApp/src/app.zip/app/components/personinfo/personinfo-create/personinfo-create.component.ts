import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { City } from '../../../models/city';
import { Country } from '../../../models/country';
import { PersonInfo } from '../../../models/person-info';
import { CityService } from '../../../services/city.service';
import { CountryService } from '../../../services/country.service';
import { NotifyService } from '../../../services/notify.service';
import { PersoninfoService } from '../../../services/personinfo.service';

@Component({
  selector: 'app-personinfo-create',
  templateUrl: './personinfo-create.component.html',
  styleUrls: ['./personinfo-create.component.css']
})
export class PersoninfoCreateComponent implements OnInit {
  personinfo: PersonInfo = new PersonInfo();
  country: Country[] = [];
  city: City[] = [];
  personinfoForm: FormGroup = new FormGroup({
    name: new FormControl('', Validators.required),
    countryId: new FormControl('', Validators.required),
    cityId: new FormControl('', Validators.required),
    languageSkills: new FormControl('', Validators.required),
    dateOfBirth: new FormControl('', Validators.required),
    resumeUpload: new FormControl('', Validators.required)
  });
  constructor(
    private personSvc: PersoninfoService,
    private countrySvc: CountryService,
    private notifySvc: NotifyService,
    private citySvc: CityService,
    private fb: FormBuilder
  ) { }

  get f() {
    return this.personinfoForm.controls;
  }

  insert() {
    if (this.personinfoForm.invalid) return;
    console.log(this.personinfoForm.value);

    Object.assign(this.personinfo, this.personinfoForm.value);
    console.log(this.personinfo);

    this.personSvc.insertPersonInfo(this.personinfo)
      .subscribe(r => {
        console.log(r);
      }, err => {
        this.notifySvc.fail("Fail to save data!!", "Dismiss");
      })
  }


  ngOnInit(): void {
    this.countrySvc.GetCountry()
      .subscribe(r => {
        this.country = r;
      }, err => {
        this.notifySvc.fail("Failed to load admission data!!", "Dismiss");
      });
  }
  public getCityById(): void {
    this
    })
  }

}
