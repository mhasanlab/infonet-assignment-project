import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personinfo-view',
  templateUrl: './personinfo-view.component.html',
  styleUrls: ['./personinfo-view.component.css']
})
export class PersoninfoViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
