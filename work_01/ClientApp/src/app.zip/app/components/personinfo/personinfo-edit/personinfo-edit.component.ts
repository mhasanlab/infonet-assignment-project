import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personinfo-edit',
  templateUrl: './personinfo-edit.component.html',
  styleUrls: ['./personinfo-edit.component.css']
})
export class PersoninfoEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
