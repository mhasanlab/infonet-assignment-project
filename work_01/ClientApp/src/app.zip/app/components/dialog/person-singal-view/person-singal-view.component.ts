import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-person-singal-view',
  templateUrl: './person-singal-view.component.html',
  styleUrls: ['./person-singal-view.component.css']
})
export class PersonSingalViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
