export class PersonInfo {
  constructor(
    public id?: number,
    public name?: string,
    public countryId?: number,
    public cityId?: number,
    public languageSkills?: string,
    public dateOfBirth?: Date,
    public resumeUpload?: string
  ) { }
}
