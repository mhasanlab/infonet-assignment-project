import { PersonInfo } from './person-info';

describe('PersonInfo', () => {
  it('should create an instance', () => {
    expect(new PersonInfo()).toBeTruthy();
  });
});
