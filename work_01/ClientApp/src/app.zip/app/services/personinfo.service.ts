import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PersonInfo } from '../models/person-info';

@Injectable({
  providedIn: 'root'
})
export class PersoninfoService {

  constructor(private http: HttpClient) { }
  getPersonInfo(): Observable<PersonInfo[]> {
    return this.http.get<PersonInfo[]>(`http://localhost:46958/api/PersonInfos`);
  }
  getPersonInfoId(id: number): Observable<PersonInfo> {
    return this.http.get<PersonInfo>(`http://localhost:29498/api/PersonInfos/${id}`);
  }
  deletePersonInfo(id: number): Observable<any> {
    return this.http.delete<PersonInfo>(`http://localhost:29498/api/PersonInfos/${id}`);
  }
  insertPersonInfo(data: PersonInfo): Observable<PersonInfo> {
    return this.http.post<PersonInfo>(`http://localhost:29498/api/PersonInfos`, data);
  }
  updatePersonInfo(data: PersonInfo): Observable<any> {
    return this.http.put(`http://localhost:29498/api/PersonInfos/${data.id}`, data);
  }
}
